library("testthat")
test_package("zoom",filter="-check") # not to use when some tests are graphics
